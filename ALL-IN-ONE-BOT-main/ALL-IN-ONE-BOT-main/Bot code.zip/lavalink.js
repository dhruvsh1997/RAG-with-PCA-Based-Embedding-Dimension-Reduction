
module.exports = {
    enabled: true, 
    lavalink: {
      name: "GlaceYT",
      password: "glace",
      host: "5.39.63.207",
      port:  8262,
      secure: false
    }
};

